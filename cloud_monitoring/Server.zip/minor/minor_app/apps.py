from django.apps import AppConfig


class MinorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'minor_app'
